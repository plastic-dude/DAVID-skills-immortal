# Intent Reading — Distributed

## Branch
**The Eye — Perception & Awareness**

## Family
Intent Reading

## Variation
Distributed

## Tier
Diamond

## Purpose
Read between lines. Understand unstated motivations.

## When to Use
- When intent reading is required at distributed level
- When complexity demands distributed approach to intent reading
- When standard methods fail and distributed is needed

## How to Apply
1. **Assess**: Evaluate the situation for intent reading requirements
2. **Prepare**: Gather resources and knowledge for distributed intent reading
3. **Execute**: Apply distributed techniques for intent reading
4. **Verify**: Confirm outcomes match intent reading objectives
5. **Iterate**: Refine based on results. Document distributed learnings.

## Key Principles
- Always verify before trusting in intent reading
- Start with fundamentals before distributed techniques
- Document everything for future intent reading reference
- Seek feedback on distributed intent reading approach
- Continuously improve intent reading capability

## Common Pitfalls
- Assuming distributed level without proper foundation
- Ignoring context when applying intent reading
- Failing to verify intent reading outcomes

## Related Skills
- The Shield — related branch
- Context Mapping — sibling family
- Intent Reading — Synthesis — alternate variation
- Self-evaluation protocol — meta-check
- Verification protocol — quality gate

## Verification Checklist
- [ ] Applied correctly
- [ ] Verified outcome
- [ ] Documented learnings
- [ ] Improved for next use

---
Skill ID: the-eye-intent-reading-distributed
Branch: the-eye
Family: intent-reading
Variation: Distributed
Tier: Diamond
Created: Thu Jul 30 07:57:47 2026
Version: 1.0
Status: ACTIVE
