# Intent Reading — Operations

## Branch
**The Eye — Perception & Awareness**

## Family
Intent Reading

## Variation
Operations

## Tier
Bronze

## Purpose
Read between lines. Understand unstated motivations.

## When to Use
- When intent reading is required at operations level
- When complexity demands operations approach to intent reading
- When standard methods fail and operations is needed

## How to Apply
1. **Assess**: Evaluate the situation for intent reading requirements
2. **Prepare**: Gather resources and knowledge for operations intent reading
3. **Execute**: Apply operations techniques for intent reading
4. **Verify**: Confirm outcomes match intent reading objectives
5. **Iterate**: Refine based on results. Document operations learnings.

## Key Principles
- Always verify before trusting in intent reading
- Start with fundamentals before operations techniques
- Document everything for future intent reading reference
- Seek feedback on operations intent reading approach
- Continuously improve intent reading capability

## Common Pitfalls
- Assuming operations level without proper foundation
- Ignoring context when applying intent reading
- Failing to verify intent reading outcomes

## Related Skills
- The Shield — related branch
- Beauty Perception — sibling family
- Intent Reading — Application — alternate variation
- Self-evaluation protocol — meta-check
- Verification protocol — quality gate

## Verification Checklist
- [ ] Applied correctly
- [ ] Verified outcome
- [ ] Documented learnings
- [ ] Improved for next use

---
Skill ID: the-eye-intent-reading-operations
Branch: the-eye
Family: intent-reading
Variation: Operations
Tier: Bronze
Created: Thu Jul 30 07:57:47 2026
Version: 1.0
Status: ACTIVE
