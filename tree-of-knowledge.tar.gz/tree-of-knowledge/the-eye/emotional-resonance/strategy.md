# Emotional Resonance — Strategy

## Branch
**The Eye — Perception & Awareness**

## Family
Emotional Resonance

## Variation
Strategy

## Tier
Bronze

## Purpose
Detect emotional undercurrents. Calibrate to audience.

## When to Use
- When emotional resonance is required at strategy level
- When complexity demands strategy approach to emotional resonance
- When standard methods fail and strategy is needed

## How to Apply
1. **Assess**: Evaluate the situation for emotional resonance requirements
2. **Prepare**: Gather resources and knowledge for strategy emotional resonance
3. **Execute**: Apply strategy techniques for emotional resonance
4. **Verify**: Confirm outcomes match emotional resonance objectives
5. **Iterate**: Refine based on results. Document strategy learnings.

## Key Principles
- Always verify before trusting in emotional resonance
- Start with fundamentals before strategy techniques
- Document everything for future emotional resonance reference
- Seek feedback on strategy emotional resonance approach
- Continuously improve emotional resonance capability

## Common Pitfalls
- Assuming strategy level without proper foundation
- Ignoring context when applying emotional resonance
- Failing to verify emotional resonance outcomes

## Related Skills
- The Eye — related branch
- Risk Perception — sibling family
- Emotional Resonance — Fundamentals — alternate variation
- Self-evaluation protocol — meta-check
- Verification protocol — quality gate

## Verification Checklist
- [ ] Applied correctly
- [ ] Verified outcome
- [ ] Documented learnings
- [ ] Improved for next use

---
Skill ID: the-eye-emotional-resonance-strategy
Branch: the-eye
Family: emotional-resonance
Variation: Strategy
Tier: Bronze
Created: Thu Jul 30 07:57:47 2026
Version: 1.0
Status: ACTIVE
